package visual;

/**
 *
 * @author silva
 */
import java.time.LocalDate;
import javax.swing.JOptionPane;

public class Diretor {
    private String nome;
    private int numeroIndentificacao;
    private LocalDate dataContratacao;
    private String cpf;

    // Construtor
    public Diretor(String nome, int numeroIndentificacao, LocalDate dataContratacao, String cpf) {
        this.nome = nome;
        setNumeroIndentificacao(numeroIndentificacao);
        setDataContratacao(dataContratacao);
        setCpf(cpf);
    }

    // Getters
    public String getNome() {
        return nome;
    }

    public int getNumeroIndentificacao() {
        return numeroIndentificacao;
    }

    public LocalDate getDataContratacao() {
        return dataContratacao;
    }

    public String getCpf() {
        return cpf;
    }

    // Setters com tratamento de dados
    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setNumeroIndentificacao(int numeroIndentificacao) {
        if (numeroIndentificacao > 0) {
            this.numeroIndentificacao = numeroIndentificacao;
        } else {
            JOptionPane.showInputDialog("Número de identificação inválido. Deve ser um valor positivo.");
        }
    }

    public void setDataContratacao(LocalDate dataContratacao) {
        // Verificando se a data de contratação é válida (não no futuro)
        if (dataContratacao.isBefore(LocalDate.now())) {
            this.dataContratacao = dataContratacao;
        } else {
            JOptionPane.showInputDialog("Data de contratação inválida. Deve ser anterior à data atual.");
        }
    }

    public void setCpf(String cpf) {
        // Removendo caracteres não numéricos do CPF
        String cpfNumerico = cpf.replaceAll("[^0-9]", "");

        if (cpfNumerico.length() == 11) {
            this.cpf = cpfNumerico;
        } else {
            JOptionPane.showInputDialog("CPF inválido. Deve conter 11 dígitos numéricos.");
        }
    }

    // Outros métodos...
}