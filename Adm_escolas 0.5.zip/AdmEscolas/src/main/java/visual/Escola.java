package visual;

/**
 *
 * @author silva
 */
import controle.EscolaControle;
import java.time.LocalDate;
import javax.swing.JOptionPane;
import visual.Sub1_1;

public class Escola extends Sub1_1 {
EscolaControle ec = new EscolaControle();

    @Override
    public void salvarvisual() {
    //INSERIR COMANDOS
    ec.salvarControle(jtfId.getText(), jtfAno.getText(), jtfEndereço.getText(), jtfNome.getText(),jtfdCpf.getText(), jtfdData.getText(), jtfdNome.getText(), jtfdNumero.getText());
    }

  
    }
    
