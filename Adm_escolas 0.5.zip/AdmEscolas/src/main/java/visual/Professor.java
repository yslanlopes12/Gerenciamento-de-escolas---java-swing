package visual;

/**
 *
 * @author silva
 */
import java.time.LocalDate;
import javax.swing.JOptionPane;

public class Professor extends Sub1_2{
   
    }

    
