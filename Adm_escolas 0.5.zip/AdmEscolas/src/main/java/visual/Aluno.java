package visual;

import javax.swing.JOptionPane;

/**
 *
 * @author silva
 */
public class Aluno extends Sub1_3  {
   
}