package modelo;

/**
 *
 * @author yslan
 */
public class EscolaModelo {
    int  id;
    int ano;
    String endereco;
    String nome;
    int dcpf;
    int ddata;
    String dnome;
    int dnumero;
    
}
