package controle;

import interfacee.InterfaceControle;

/**
 *
 * @author yslan
 */
public class EscolaControle implements InterfaceControle{

    @Override
    public void salvarControle(Object... valor) {
       
    }

    @Override
    public void excluir(int id) {
    }

    @Override
    public void carregarComboBox() {
    }
    
}
