package modelo;

/**
 *
 * @author yslan
 */
public class EscolaModelo {

    private int id;
    private int ano;
    private String endereco;
    private String nome;
    private int dcpf;
    private int ddata;
    private String dnome;
    private int dnumero;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getDcpf() {
        return dcpf;
    }

    public void setDcpf(int dcpf) {
        this.dcpf = dcpf;
    }

    public int getDdata() {
        return ddata;
    }

    public void setDdata(int ddata) {
        this.ddata = ddata;
    }

    public String getDnome() {
        return dnome;
    }

    public void setDnome(String dnome) {
        this.dnome = dnome;
    }

    public int getDnumero() {
        return dnumero;
    }

    public void setDnumero(int dnumero) {
        this.dnumero = dnumero;
    }

}
