package visual;

/**
 *
 * @author silva
 */
import controle.EscolaControle;
import java.time.LocalDate;
import javax.swing.JOptionPane;
import visual.Sub1_1;

public class Escola extends Sub1_1 {

    EscolaControle ec = new EscolaControle();

    @Override
    public void salvarvisual() {
        //INSERIR COMANDOS
        ec.salvarControle(Integer.parseInt(jtfId.getText()), Integer.parseInt(jtfAno.getText()), jtfEndereço.getText(), jtfNome.getText(), Integer.parseInt(jtfdCpf.getText()), Integer.parseInt(jtfdData.getText()), jtfdNome.getText(), Integer.parseInt(jtfdNumero.getText()));
    }

}
