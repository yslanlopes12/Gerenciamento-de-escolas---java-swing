package visual;

/**
 *
 * @author silva
 */


import controle.AlunoControle;
import controle.CursosControle;
import java.time.LocalDate;
import javax.swing.JOptionPane;

public class Curso extends Sub1_4 {

    CursosControle cc = new CursosControle();
    
    @Override
    public void salvarvisual() {
        cc.salvarControle(jtfEscola.getText(), Integer.parseInt(jtfCodigo.getText()), jtfDescricao.getText(),Integer.parseInt(jtfAno.getText()));
    }
  
}