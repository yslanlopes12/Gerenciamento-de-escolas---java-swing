package visual;

/**
 *
 * @author silva
 */
import controle.ProfessorControle;
import java.time.LocalDate;

public class Professor extends Sub1_2 {

    ProfessorControle pc = new ProfessorControle();

    @Override

    public void salvarvisual() {
        //INSERIR COMANDOS
        pc.salvarControle(Integer.parseInt(jtfCpf.getText()), Integer.parseInt(jtfData.getText()), jtfNome.getText(), jtfDisciplina.getText(), Integer.parseInt(jtfNumero.getText()));
    }

}
