package controle;

import dao.EscolaDao;
import interfacee.InterfaceControle;
import modelo.EscolaModelo;

/**
 *
 * @author yslan
 */
public class EscolaControle implements InterfaceControle {

    EscolaModelo em = new EscolaModelo();
    EscolaDao ed = new EscolaDao();

    @Override
    public void salvarControle(Object... valor) {
        
        if ("".equals(valor[0])) {
            em.setId(0);
        } else {
            em.setId((int) valor[0]);
        }
        
        //////////////////////////////////
        
        if ("".equals(valor[0])) {
            em.setAno(1); }
        else{
        em.setAno((int) valor[1]);}
        
        //////////////////////////////////
        
        em.setEndereco((String) valor[2]);
        
        em.setNome((String) valor[3]);
        
        //////////////////////////////////
        if ("".equals(valor[4])) {
            em.setDcpf(4);
        } else {
        em.setDcpf((int) valor[4]);}
        
        //////////////////////////////////
        
       if ("".equals(valor[5])) {
            em.setDdata(5);
        } else { 
        em.setDdata((int) valor[5]);
       }
       
       ///////////////////////////////////
       
        em.setDnome((String) valor[6]);
        
        //////////////////////////////////
        
        if ("".equals(valor[7])) {
            em.setDnumero(7);
        } else { 
        em.setDnumero((int) valor[7]);}
        // controle envia as informações para o dao

        ed.salvarDao(em);
    }

    @Override
    public void excluir(int id) {
    }

    @Override
    public void carregarComboBox() {
    }

}
