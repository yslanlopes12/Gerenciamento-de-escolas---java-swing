package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author yslan
 */
public class ConexaoBanco {
    private static final String  driveClass = "com.mysql.jdbc.Driver";
    private static final String url = "jdbc://localhost:3306/contatobd";    
    private static final String usuario = "root";
    private static final String senha = "";
    
    public  Connection abreconexao() {
        Connection con = null;
        
        try {
            Class.forName("con.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url,usuario , senha);
             JOptionPane.showMessageDialog(null, "conectado com sucesso");
            
        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, "Erro ao conectar com banco dedados: " + erro);
        }
        
        
        
        
        return con;
    }
}
