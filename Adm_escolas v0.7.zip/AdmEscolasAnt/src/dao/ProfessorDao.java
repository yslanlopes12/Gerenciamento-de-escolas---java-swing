package dao;

import interfacee.InterfaceDao;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.ProfessorModelo;
import visual.Sub1;

public class ProfessorDao implements InterfaceDao {

    @Override
    public void salvarDao(Object... valor) {
        ProfessorModelo pm = (ProfessorModelo) valor[0];
        

        JOptionPane.showMessageDialog(null, "Professor: " + pm.getNome() + "\nCadastrado com Sucesso!");
        Sub1 tela = new Sub1();
        tela.jdesktop2.add(tela);
        tela.setVisible(true);
    }

    @Override
    public void excluirDao(int id) {

    }

    @Override
    public void consultarDao(Object... valor) throws SQLException {

    }

    @Override
    public void carregarComboBoxDao(JComboBox itens) throws SQLException {
    }

}
