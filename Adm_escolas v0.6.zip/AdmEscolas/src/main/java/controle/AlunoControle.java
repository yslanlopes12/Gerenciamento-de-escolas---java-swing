package controle;


import dao.AlunoDao;
import dao.ProfessorDao;
import interfacee.InterfaceControle;
import modelo.AlunoModelo;
import modelo.ProfessorModelo;

/**
 *
 * @author yslan
 */
public class AlunoControle implements InterfaceControle {

    AlunoModelo am = new AlunoModelo();
    AlunoDao ad = new AlunoDao();

    @Override
    public void salvarControle(Object... valor) {
        
        am.setNome((String) valor[0]);
        
///////////////////////////////
        if ("".equals(valor[0])) {
            am.setMatricula(0);
        } else {
            am.setCpf((int) valor[1]);
        }
        
        //////////////////////////////////
        
        if ("".equals(valor[0])) {
            am.setSerie(0); }
        else{
        am.setSerie((int) valor[2]);}
        
        //////////////////////////////////
        
        if ("".equals(valor[0])) {
            am.setData(0);
        } else {
        am.setData((int) valor[3]);}
        
        //////////////////////////////////
       
        if ("".equals(valor[0])) {
            am.setCpf(0);
        } else {
            am.setCpf((int) valor[4]);
        }
        
         ad.salvarDao(am);
    }

    @Override
    public void excluir(int id) {
    }

    @Override
    public void carregarComboBox() {
    }

}
