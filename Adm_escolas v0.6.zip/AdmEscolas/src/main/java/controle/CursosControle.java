package controle;


import dao.AlunoDao;
import dao.CursoDao;
import dao.ProfessorDao;
import interfacee.InterfaceControle;
import modelo.AlunoModelo;
import modelo.CursoModelo;
import modelo.ProfessorModelo;

/**
 *
 * @author yslan
 */
public class CursosControle implements InterfaceControle {

    CursoModelo cm = new CursoModelo();
    CursoDao cd = new CursoDao();

    @Override
    public void salvarControle(Object... valor) {
        
        cm.setEscola((String) valor[0]);
        
///////////////////////////////
        if ("".equals(valor[0])) {
            cm.setCodigo(0);
        } else {
            cm.setCodigo((int) valor[1]);
        }
        
        //////////////////////////////////
        
         cm.setDescricao((String) valor[2]);
         
       ///////////////////////////////////
       
        if ("".equals(valor[0])) {
            cm.setAno(0);
        } else {
            cm.setAno((int) valor[3]);
        }
        
         cd.salvarDao(cm);
    }

    @Override
    public void excluir(int id) {
    }

    @Override
    public void carregarComboBox() {
    }

}