package controle;


import dao.ProfessorDao;
import interfacee.InterfaceControle;
import modelo.ProfessorModelo;

/**
 *
 * @author yslan
 */
public class ProfessorControle implements InterfaceControle {

    ProfessorModelo pm = new ProfessorModelo();
    ProfessorDao pd = new ProfessorDao();

    @Override
    public void salvarControle(Object... valor) {
        
        if ("".equals(valor[0])) {
            pm.setCpf(0);
        } else {
            pm.setCpf((int) valor[0]);
        }
        
        //////////////////////////////////
        
        if ("".equals(valor[0])) {
            pm.setData(0); }
        else{
        pm.setData((int) valor[0]);}
        
        //////////////////////////////////
        
        pm.setNome((String) valor[2]);
        
        //////////////////////////////////
        if ("".equals(valor[0])) {
            pm.setNumero(0);
        } else {
        pm.setNumero((int) valor[0]);}
        
        //////////////////////////////////
       
        pm.setDisciplina((String) valor[3]);
        
         pd.salvarDao(pm);
    }

    @Override
    public void excluir(int id) {
    }

    @Override
    public void carregarComboBox() {
    }

}
