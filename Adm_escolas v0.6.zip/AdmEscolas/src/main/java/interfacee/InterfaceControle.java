package interfacee;

/**
 *
 * @author yslan
 */
public interface InterfaceControle {

    public void salvarControle(Object... valor);

    public void excluir(int id);

    public void carregarComboBox();

}
