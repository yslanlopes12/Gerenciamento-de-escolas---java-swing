package dao;

import interfacee.InterfaceDao;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.AlunoModelo;
import modelo.ProfessorModelo;
import visual.Sub1;

/**
 *
 * @author yslan
 */
public class AlunoDao implements InterfaceDao {

    @Override
    public void salvarDao(Object... valor) {
 AlunoModelo am = (AlunoModelo) valor[0];
        

        JOptionPane.showMessageDialog(null, "Aluno: " + am.getNome() + "\nCadastrado com Sucesso!");
        JOptionPane.showMessageDialog(null, "Notas: 5, 8, 9, 7 " + "\nMédia: 7.25 " + "\nPortanto, o desvio padrão das Notas 5, 8, 9, 7 é aproximadamente 1.48.");
        Sub1 tela = new Sub1();
        tela.jdesktop2.add(tela);
        tela.setVisible(true);
    }

    @Override
    public void excluirDao(int id) {
   
    }

    @Override
    public void consultarDao(Object... valor) throws SQLException {
  
    
    }

    @Override
    public void carregarComboBoxDao(JComboBox itens) throws SQLException {


    }
    
}
