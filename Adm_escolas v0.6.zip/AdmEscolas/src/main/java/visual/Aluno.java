package visual;

import controle.AlunoControle;
import controle.ProfessorControle;
import javax.swing.JOptionPane;

/**
 *
 * @author silva
 */
public class Aluno extends Sub1_3 {

    AlunoControle ac = new AlunoControle();

    @Override
    public void salvarvisual() {
        ac.salvarControle(jtfNome.getText(), Integer.parseInt(jtfMatricula.getText()), Integer.parseInt(jtfSerie.getText()), Integer.parseInt(jtfData.getText()), Integer.parseInt(jtfCpf.getText()));

    }

}
